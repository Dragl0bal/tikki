import React, { Suspense, useEffect, useMemo, useRef, useState } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Float, Sparkles, Stars, Text, Trail } from '@react-three/drei'
import * as THREE from 'three'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { ArrowDown, ArrowUpRight, Volume2, VolumeX, Sparkle } from 'lucide-react'

gsap.registerPlugin(ScrollTrigger)

const chapters = [
  { id: 'arrival', number: '01', eyebrow: 'ENTER THE PORTAL', title: 'Work in another dimension.', body: 'AI is the doorway. A better way of working is what waits on the other side.', node: 'THE GATE', color: '#65f4df' },
  { id: 'intelligence', number: '02', eyebrow: 'TOP AI, IN ITS ELEMENT', title: 'Meet your new kind of intelligence.', body: 'Choose the right model for the task. Give it better context. Get more from every interaction.', node: 'AI CAPABILITIES', color: '#c69bff' },
  { id: 'networks', number: '03', eyebrow: 'CONNECTED NETWORKS', title: 'Make every part talk to the next.', body: 'Bring your tools, knowledge and ideas into one connected current. Less repetition. More momentum.', node: 'CONNECTIONS', color: '#63eaff' },
  { id: 'workflows', number: '04', eyebrow: 'SEAMLESS WORKFLOWS', title: 'Turn the current into progress.', body: 'Build repeatable systems that move from question to useful output — without the unnecessary loops.', node: 'WORKFLOWS', color: '#ffce72' },
  { id: 'arrival-end', number: '05', eyebrow: 'STEP INTO WHAT’S NEXT', title: 'Less friction. More possibility.', body: 'Bring us the process that slows you down. We’ll find a smarter way through.', node: 'YOUR NEXT MOVE', color: '#65f4df' },
]

function makeMaskGeometry() {
  const g = new THREE.Group()
  const gold = new THREE.MeshStandardMaterial({ color: '#ffcb72', metalness: .78, roughness: .24, emissive: '#5b260d', emissiveIntensity: .45 })
  const dark = new THREE.MeshStandardMaterial({ color: '#14263c', metalness: .65, roughness: .28, emissive: '#063f51', emissiveIntensity: .7 })
  const glow = new THREE.MeshStandardMaterial({ color: '#75ffe6', emissive: '#27e9d1', emissiveIntensity: 2.2, metalness: .35, roughness: .18 })
  const face = new THREE.Mesh(new THREE.OctahedronGeometry(1.12, 1), gold)
  face.scale.set(.82, 1.08, .5)
  g.add(face)
  const brow = new THREE.Mesh(new THREE.TorusGeometry(.56, .075, 8, 32, Math.PI), glow)
  brow.position.set(0, .28, .48); brow.rotation.z = Math.PI
  g.add(brow)
  for (const x of [-.37, .37]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(.12, 16, 12), glow)
    eye.position.set(x, .08, .52); g.add(eye)
    const socket = new THREE.Mesh(new THREE.TorusGeometry(.19, .035, 8, 24), dark)
    socket.position.set(x, .08, .49); g.add(socket)
  }
  const nose = new THREE.Mesh(new THREE.ConeGeometry(.16, .43, 5), dark)
  nose.position.set(0, -.18, .51); nose.rotation.x = .16; g.add(nose)
  const mouth = new THREE.Mesh(new THREE.TorusGeometry(.25, .055, 8, 24, Math.PI), glow)
  mouth.position.set(0, -.52, .47); mouth.rotation.z = Math.PI; g.add(mouth)
  for (const side of [-1, 1]) {
    const ear = new THREE.Mesh(new THREE.CylinderGeometry(.13, .22, .18, 6), gold)
    ear.position.set(side * .83, -.04, .1); ear.rotation.z = side * -.22; g.add(ear)
    for (let i = 0; i < 3; i++) {
      const rune = new THREE.Mesh(new THREE.BoxGeometry(.055, .18, .04), glow)
      rune.position.set(side * (.7 + i * .06), .5 - i * .14, .42); rune.rotation.z = side * .4; g.add(rune)
    }
  }
  const crown = new THREE.Mesh(new THREE.ConeGeometry(.34, .58, 5), dark)
  crown.position.y = 1.2; crown.rotation.y = .3; g.add(crown)
  return g
}

function TikiMask({ position = [0,0,0], scale = 1, variant = 0, mouse }) {
  const ref = useRef()
  const geometry = useMemo(makeMaskGeometry, [])
  useFrame((state, delta) => {
    if (!ref.current) return
    const t = state.clock.elapsedTime
    ref.current.rotation.y += (mouse.current.x * .25 + Math.sin(t * .45 + variant) * .08 - ref.current.rotation.y) * Math.min(1, delta * 2)
    ref.current.rotation.x += (mouse.current.y * -.12 + Math.sin(t * .6 + variant) * .04 - ref.current.rotation.x) * Math.min(1, delta * 2)
    ref.current.position.y = position[1] + Math.sin(t * .8 + variant) * .12
  })
  return <group ref={ref} position={position} scale={scale}><primitive object={geometry} /></group>
}

function PortalTunnel({ progress, mouse, chapter }) {
  const group = useRef()
  const rings = useRef([])
  const { viewport } = useThree()
  const ringData = useMemo(() => Array.from({ length: 24 }, (_, i) => ({
    z: -i * 4.1, radius: 2.1 + Math.sin(i * 1.4) * .25, rotation: i * .24,
    hue: i % 3 === 0 ? '#ffce72' : i % 3 === 1 ? '#61f4df' : '#9a75ff',
  })), [])
  useFrame((state, delta) => {
    const t = state.clock.elapsedTime
    if (group.current) {
      group.current.rotation.z += (mouse.current.x * .035 - group.current.rotation.z) * delta * 1.4
      group.current.rotation.x += (-mouse.current.y * .025 - group.current.rotation.x) * delta * 1.4
      group.current.position.z = THREE.MathUtils.damp(group.current.position.z, progress.current * 20, 4, delta)
    }
    rings.current.forEach((ring, i) => {
      if (!ring) return
      ring.rotation.z = ringData[i].rotation + t * (.06 + i * .001) + progress.current * .22
      ring.rotation.x = Math.sin(t * .22 + i) * .08
      const pulse = 1 + Math.sin(t * 1.25 - i * .42 + progress.current * 8) * .025
      ring.scale.setScalar(pulse)
    })
  })
  return <group ref={group}>
    {ringData.map((r, i) => <group key={i} ref={el => rings.current[i] = el} position={[Math.sin(i * .6) * .22, Math.cos(i * .45) * .2, r.z]} rotation={[0,0,r.rotation]}>
      <mesh>
        <torusGeometry args={[r.radius, .026 + (i % 3) * .008, 8, 72]} />
        <meshStandardMaterial color={r.hue} emissive={r.hue} emissiveIntensity={1.5 + Math.sin(i) * .5} metalness={.45} roughness={.3} />
      </mesh>
      {Array.from({length: 8}, (_, j) => <mesh key={j} position={[Math.cos(j*Math.PI/4)*r.radius, Math.sin(j*Math.PI/4)*r.radius, 0]} rotation={[0,0,j*Math.PI/4]}>
        <octahedronGeometry args={[.065 + (j%2)*.02, 0]} />
        <meshStandardMaterial color={r.hue} emissive={r.hue} emissiveIntensity={2} />
      </mesh>)}
    </group>)}
    <mesh position={[0,0,-102]}>
      <sphereGeometry args={[2.8, 48, 48]} />
      <meshBasicMaterial color="#7b54ff" wireframe transparent opacity={.16} />
    </mesh>
  </group>
}

function ParticleField({ mouse, progress }) {
  const ref = useRef()
  const count = 1700
  const positions = useMemo(() => {
    const a = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      const z = -Math.random() * 110
      const angle = Math.random() * Math.PI * 2
      const r = 1.3 + Math.random() * 9
      a[i*3] = Math.cos(angle) * r
      a[i*3+1] = Math.sin(angle) * r
      a[i*3+2] = z
    }
    return a
  }, [])
  useFrame((state, delta) => {
    if (!ref.current) return
    ref.current.rotation.z += delta * (.012 + progress.current * .05)
    ref.current.rotation.x = THREE.MathUtils.damp(ref.current.rotation.x, mouse.current.y * .025, 2, delta)
    ref.current.position.x = THREE.MathUtils.damp(ref.current.position.x, -mouse.current.x * .35, 2, delta)
    ref.current.position.y = THREE.MathUtils.damp(ref.current.position.y, -mouse.current.y * .25, 2, delta)
    const m = ref.current.material
    m.size = .025 + progress.current * .025 + Math.sin(state.clock.elapsedTime * 2.2) * .006
  })
  return <points ref={ref}>
    <bufferGeometry><bufferAttribute attach="attributes-position" count={count} array={positions} itemSize={3} /></bufferGeometry>
    <pointsMaterial color="#8ef9f0" size={.03} transparent opacity={.78} sizeAttenuation depthWrite={false} blending={THREE.AdditiveBlending} />
  </points>
}

function NetworkConstellation({ mouse }) {
  const group = useRef()
  const nodes = useMemo(() => Array.from({length: 42}, (_, i) => new THREE.Vector3(
    (Math.random()-.5)*5.5, (Math.random()-.5)*4.3, -30 - Math.random()*3
  )), [])
  const linePositions = useMemo(() => {
    const arr = []
    nodes.forEach((n, i) => {
      const next = nodes[(i + 1) % nodes.length]
      arr.push(n.x,n.y,n.z,next.x,next.y,next.z)
      if (i % 2 === 0) { const other = nodes[(i + 7) % nodes.length]; arr.push(n.x,n.y,n.z,other.x,other.y,other.z) }
    })
    return new Float32Array(arr)
  }, [nodes])
  useFrame((state, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * .04
      group.current.rotation.x = mouse.current.y * .06
    }
  })
  return <group ref={group}>
    <lineSegments>
      <bufferGeometry><bufferAttribute attach="attributes-position" count={linePositions.length/3} array={linePositions} itemSize={3} /></bufferGeometry>
      <lineBasicMaterial color="#65eaff" transparent opacity={.36} />
    </lineSegments>
    {nodes.map((n, i) => <mesh key={i} position={n}>
      <icosahedronGeometry args={[i % 6 === 0 ? .13 : .055, 1]} />
      <meshStandardMaterial color={i%4===0?'#ffce72':'#65eaff'} emissive={i%4===0?'#ff9d44':'#29c9ff'} emissiveIntensity={2.4} />
    </mesh>)}
  </group>
}

function DataRiver() {
  const ref = useRef()
  const curves = useMemo(() => Array.from({length: 7}, (_, i) => {
    const pts = []
    for (let j=0;j<60;j++) {
      const z = -42 - j * 1.2
      const x = Math.sin(j*.16 + i*1.2) * (1.2 + i*.13)
      const y = Math.cos(j*.12 + i*.8) * (1 + i*.09)
      pts.push(new THREE.Vector3(x,y,z))
    }
    return new THREE.CatmullRomCurve3(pts)
  }), [])
  useFrame((state) => {
    if (ref.current) ref.current.children.forEach((line,i) => { line.material.opacity = .4 + Math.sin(state.clock.elapsedTime*2+i)*.22 })
  })
  return <group ref={ref}>{curves.map((curve,i) => <mesh key={i}>
    <tubeGeometry args={[curve, 120, .018 + (i%3)*.008, 6, false]} />
    <meshBasicMaterial color={i%2?'#b88aff':'#65f4df'} transparent opacity={.55} />
  </mesh>)}</group>
}

function CameraRig({ progress, mouse }) {
  const { camera } = useThree()
  useFrame((state, delta) => {
    const p = progress.current
    const targetZ = 4 - p * 82
    camera.position.z = THREE.MathUtils.damp(camera.position.z, targetZ, 3.4, delta)
    camera.position.x = THREE.MathUtils.damp(camera.position.x, mouse.current.x * .55, 2.1, delta)
    camera.position.y = THREE.MathUtils.damp(camera.position.y, mouse.current.y * .35, 2.1, delta)
    camera.rotation.z = THREE.MathUtils.damp(camera.rotation.z, -mouse.current.x * .035, 2, delta)
    camera.lookAt(camera.position.x * .18, camera.position.y * .18, camera.position.z - 8)
    camera.fov = THREE.MathUtils.damp(camera.fov, 58 + Math.abs(p - (progress.previous || 0)) * 100, 2, delta)
    camera.updateProjectionMatrix()
    progress.previous = p
  })
  return null
}

function World({ progress, mouse, chapter }) {
  return <>
    <fog attach="fog" args={['#08051b', 13, 100]} />
    <ambientLight intensity={.55} />
    <pointLight position={[0,0,2]} color="#65f4df" intensity={22} distance={22} />
    <pointLight position={[3,2,-24]} color="#8c5cff" intensity={16} distance={35} />
    <pointLight position={[-3,-2,-45]} color="#ffbf62" intensity={12} distance={24} />
    <Stars radius={100} depth={90} count={1800} factor={4} saturation={.5} fade speed={1.3} />
    <ParticleField mouse={mouse} progress={progress} />
    <PortalTunnel progress={progress} mouse={mouse} chapter={chapter} />
    <Float speed={1.1} rotationIntensity={.08} floatIntensity={.15}><TikiMask position={[-2.2,.6,-15]} scale={.72} variant={1} mouse={mouse} /></Float>
    <Float speed={1.3} rotationIntensity={.12} floatIntensity={.2}><TikiMask position={[2.4,-.7,-34]} scale={.9} variant={2} mouse={mouse} /></Float>
    <Float speed={.9} rotationIntensity={.1} floatIntensity={.12}><TikiMask position={[-2.1,-.8,-53]} scale={.82} variant={3} mouse={mouse} /></Float>
    <NetworkConstellation mouse={mouse} />
    <DataRiver />
    <CameraRig progress={progress} mouse={mouse} />
  </>
}

function SoundToggle() {
  const [on, setOn] = useState(false)
  const audioRef = useRef(null)
  const nodesRef = useRef(null)
  const start = () => {
    if (on) {
      nodesRef.current?.oscillators.forEach(o => { try { o.stop() } catch {} })
      nodesRef.current?.ctx.close()
      nodesRef.current = null
      setOn(false)
      return
    }
    const ctx = new (window.AudioContext || window.webkitAudioContext)()
    const master = ctx.createGain()
    master.gain.value = .025
    master.connect(ctx.destination)
    const oscillators = [55, 82.41, 110].map((hz, i) => {
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.type = i === 1 ? 'sine' : 'triangle'
      osc.frequency.value = hz
      gain.gain.value = i === 0 ? .5 : .18
      osc.connect(gain); gain.connect(master); osc.start()
      return osc
    })
    nodesRef.current = { ctx, oscillators }
    setOn(true)
  }
  useEffect(() => () => { nodesRef.current?.ctx.close() }, [])
  return <button className="sound-toggle" onClick={start} aria-label={on ? 'Turn ambient sound off' : 'Turn ambient sound on'}>
    {on ? <Volume2 size={16}/> : <VolumeX size={16}/>} <span>{on ? 'AMBIENCE ON' : 'SOUND OFF'}</span>
  </button>
}

function App() {
  const progress = useRef(0)
  const mouse = useRef({x:0,y:0})
  const [chapter, setChapter] = useState(0)
  const [contact, setContact] = useState({name:'',email:'',message:''})
  const stageRef = useRef(null)
  const chapterRefs = useRef([])
  const activeColor = chapters[chapter]?.color || '#65f4df'

  useEffect(() => {
    const ctx = gsap.context(() => {
      chapterRefs.current.forEach((el, i) => {
        if (!el) return
        gsap.fromTo(el.querySelectorAll('.reveal'), { y: 45, opacity: 0, filter: 'blur(8px)' }, {
          y: 0, opacity: 1, filter: 'blur(0px)', duration: 1.1, stagger: .14, ease: 'power3.out',
          scrollTrigger: { trigger: el, start: 'top 66%', end: 'bottom 45%', toggleActions: 'play reverse play reverse',
            onEnter: () => setChapter(i), onEnterBack: () => setChapter(i) }
        })
      })
      ScrollTrigger.create({
        trigger: stageRef.current, start: 'top top', end: 'bottom bottom',
        onUpdate: self => { progress.current = self.progress }
      })
    }, stageRef)
    return () => ctx.revert()
  }, [])

  useEffect(() => {
    const move = e => {
      mouse.current.x = (e.clientX / window.innerWidth) * 2 - 1
      mouse.current.y = (e.clientY / window.innerHeight) * 2 - 1
    }
    window.addEventListener('pointermove', move, {passive:true})
    return () => window.removeEventListener('pointermove', move)
  }, [])

  const submit = e => {
    e.preventDefault()
    const subject = encodeURIComponent('Tiki Portal — let’s improve a workflow')
    const body = encodeURIComponent(`Name: ${contact.name}\nEmail: ${contact.email}\n\n${contact.message}`)
    window.location.href = `mailto:hello@example.com?subject=${subject}&body=${body}`
  }

  return <main className="portal-shell" style={{'--accent':activeColor}}>
    <div className="world-canvas" aria-hidden="true">
      <Canvas dpr={[1,1.7]} camera={{position:[0,0,4],fov:58}} gl={{antialias:true,alpha:true}}>
        <Suspense fallback={null}><World progress={progress} mouse={mouse} chapter={chapter}/></Suspense>
      </Canvas>
    </div>
    <div className="vignette" aria-hidden="true" />
    <header className="topbar">
      <a className="brand" href="#arrival" aria-label="Tiki Portal home"><span className="brand-mark"><Sparkle size={17}/></span><span>TIKI<span className="brand-light">PORTAL</span></span></a>
      <div className="top-right"><span className="live-dot"/> <span className="top-label">A BETTER WAY THROUGH</span><SoundToggle/></div>
    </header>
    <div className="depth-meter"><div style={{height:`${(chapter+1)/chapters.length*100}%`}}/><span>DEPTH<br/>{String(chapter+1).padStart(2,'0')} / 05</span></div>

    <div className="scroll-stage" ref={stageRef}>
      {chapters.map((c, i) => <section id={c.id} key={c.id} className={`chapter chapter-${i}`} ref={el => chapterRefs.current[i] = el}>
        <div className={`chapter-content ${i%2===1?'align-right':''}`}>
          <p className="eyebrow reveal"><span>{c.number}</span> {c.eyebrow}</p>
          <h1 className="reveal">{c.title}</h1>
          <p className="chapter-body reveal">{c.body}</p>
          <div className="node-tag reveal"><span className="node-pulse"/>{c.node}</div>
          {i===0 && <a className="scroll-cue reveal" href="#intelligence"><span className="cue-icon"><ArrowDown size={15}/></span> SURF INTO THE UNKNOWN</a>}
          {i===4 && <form className="contact-form reveal" onSubmit={submit}>
            <label><span>Your name</span><input value={contact.name} onChange={e=>setContact({...contact,name:e.target.value})} required placeholder="Name"/></label>
            <label><span>Email address</span><input type="email" value={contact.email} onChange={e=>setContact({...contact,email:e.target.value})} required placeholder="you@company.com"/></label>
            <label><span>Where’s the friction?</span><textarea value={contact.message} onChange={e=>setContact({...contact,message:e.target.value})} required rows="3" placeholder="Tell us what you want to make easier…"/></label>
            <button className="submit-button" type="submit">LET’S FIND A BETTER WAY <ArrowUpRight size={16}/></button>
            <small>Opens your email app with a message ready to send.</small>
          </form>}
        </div>
        <div className="chapter-index" aria-hidden="true"><span>{c.number}</span><i/></div>
      </section>)}
    </div>
    <footer className="footer-line"><span>MOVE WITH THE CURRENT</span><span>SCROLL TO TRAVEL <span className="footer-arrow">↓</span></span></footer>
  </main>
}

export default App
